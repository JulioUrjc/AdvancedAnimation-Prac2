#include "RigidBody.h"

const RigidBody RigidBody::RIGIDBODYVOID;